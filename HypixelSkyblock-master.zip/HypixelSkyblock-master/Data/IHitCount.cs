namespace Coflnet.Sky.Core
{
    public interface IHitCount
    {
        int HitCount { get; set; }
    }
}