using System;

namespace Coflnet.Sky.Core
{
    public class BinInfo
    {
        public DateTime End { get; set; }
        public string Auctioneer { get; set; }
    }
}